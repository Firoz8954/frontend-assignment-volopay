import React from 'react';
import "./style.css"

function Filter(){
    return (
        <>
        <div className='filter-container'>
        <button>
            Filter
        </button>
        </div>

        </>
    )
}

export default Filter;