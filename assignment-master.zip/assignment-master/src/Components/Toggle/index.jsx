import './style.css';

function Toggle() {
  return (
    <>
    <div className='container'>
      <button>
        Your
      </button>
      <button>
        All
      </button>
      <button>
        Blocked
      </button>
    </div>
    </>
    
  );
}

export default Toggle;
